import java.util.*;

public class Cerny1 {

   public static int[] pole;
   public static int[] pole2;
   public static int soucet1=0;
   public static int soucet2=0;
   public static String vetsi;
    public static void main(String[] args) {
        
        Napln();
        vypis();
        System.out.println(vetsi);
        
       

    }

    public static void Napln(){

        Scanner sc = new Scanner(System.in);

        System.out.println("Kolik chcete hodnot?");
        pole = new int[sc.nextInt()];

        for (int i = 0; i <pole.length ; i++) {
            System.out.println("Zadejte hodnotu");
            pole[i]=sc.nextInt();
            
        }
    }

    public static void vypis(){

        pole2 = new int[pole.length];

        if(pole.length %2==0){

            for (int i = 0; i < pole.length; i++) {
                if(i>=pole.length/2){
                    pole2[i] = pole[i];
                    pole[i]=0;
                    
                }
            }

        }else{

            for (int i = 0; i < pole.length; i++) {

                if(i>=pole.length/2-0.5||i>=pole.length/2+0.5){
                    pole2[i]=pole[i]; 
                    pole[i]=0;
                }


                
            }
           

        }
            
        for (int i = 0; i < pole.length; i++) {
            soucet1 +=pole[i];
        }
        for (int i = 0; i < pole2.length; i++) {
            soucet2 = pole2[i];
        }

        if(soucet1==soucet2){
            vetsi="Obě poloviny jsou stejně velké";
        }else{

        
        if(soucet1>soucet2){
            vetsi ="První polovina je větší";
        }else{
            vetsi="Druha polovina je větší";
        }
        }


    }

}
